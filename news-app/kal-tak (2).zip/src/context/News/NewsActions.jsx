export const fetchNews = async (topic) => {
  const response = await fetch(
    `https://newsapi.org/v2/everything?q=${topic}&from=2023-10-01&sortBy=publishedAt&apiKey=73047d367b264236b5605b0016384814`
  );
  const data = await response.json();
  return data.articles;
};
