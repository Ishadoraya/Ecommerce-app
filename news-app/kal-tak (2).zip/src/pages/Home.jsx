import React, { useContext, useEffect } from "react";
import NewsCard from "../components/NewsCard";
import Carousal from "../components/Carousal";
import NewsContext from "../context/News/NewsContext";
import { fetchNews } from "../context/News/NewsActions";

const Home = () => {
  const { allNews, dispatch } = useContext(NewsContext);

  const getNews = async () => {
    const data = await fetchNews("Indore");
    dispatch({
      type: "GET_NEWS",
      payload: data,
    });
  };

  useEffect(() => {
    getNews();
  }, []);

  if (!allNews) {
    return <h1 className="text-center display-1">Loading...</h1>;
  }

  return (
    <div className="container p-3">
      <Carousal />

      <h1 className="display-5 text-center">Top News Today</h1>

      {/* Card Container */}

      <div className="row p-3">
        {allNews.map((news, index) => (
          <NewsCard key={index} news={news} />
        ))}
      </div>
    </div>
  );
};

export default Home;
