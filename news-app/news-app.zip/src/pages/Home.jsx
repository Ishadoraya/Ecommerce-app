import React from 'react'
import Newslist from '../components/Newslist'

const Home = () => {
  return (
    <div className="container p-5">
        <Newslist/>
    </div>
  )
}

export default Home
