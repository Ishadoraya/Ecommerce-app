import React from 'react'
import NewsCard from './NewsCard'

const Newslist = () => {
  return (
    <>
    <NewsCard/>
    <NewsCard/>
    <NewsCard/>
    <NewsCard/>
    <NewsCard/>
    </>
  )
}

export default Newslist
